from utils import _find_getch
import theGame

getch = _find_getch()
theGame.theGame().play()