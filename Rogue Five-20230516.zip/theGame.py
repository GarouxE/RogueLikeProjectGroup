from Game import Game

def theGame(game=Game()):
    """Game singleton"""
    return game