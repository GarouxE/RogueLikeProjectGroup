import Interface

jeu = Interface.Ecran()
jeu.run()
